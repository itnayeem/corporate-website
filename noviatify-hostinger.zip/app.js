// Hostinger shared-hosting (Passenger / CloudLinux Node.js Selector) startup file.
// Set this as the "Application startup file" in hPanel. Do not run it manually.
process.env.NODE_ENV = process.env.NODE_ENV || "production";
process.env.PORT = process.env.PORT || "3000";

import("./index.mjs").catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
